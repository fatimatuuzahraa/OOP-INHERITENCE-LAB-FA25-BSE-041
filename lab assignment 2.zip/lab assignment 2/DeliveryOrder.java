class DeliveryOrder extends FoodOrder {
    private String address;

    public DeliveryOrder(String orderId, String customerName, double amount, String address) {
        super(orderId, customerName, amount);
        this.address = address;
    }

    @Override
    public void processOrder() {
        System.out.println("Processing delivery order to address: " + address);
    }

    @Override
    public void calculateBill() {
        amount = amount + 100;
    }

    @Override
    public String toString() {
        return "DeliveryOrder [ID=" + orderId + ", Customer=" + customerName + ", Amount=" + amount + ", Address=" + address + "]";
    }
}
