class TakeAwayOrder extends FoodOrder {
    private boolean packaging;

    public TakeAwayOrder(String orderId, String customerName, double amount, boolean packaging) {
        super(orderId, customerName, amount);
        this.packaging = packaging;
    }

    @Override
    public void processOrder() {
        System.out.println("Processing takeaway order with packaging: " + packaging);
    }

    @Override
    public void calculateBill() {
        if (packaging) {
            amount = amount + 50;
        }
    }

    @Override
    public String toString() {
        return "TakeAwayOrder [ID=" + orderId + ", Customer=" + customerName + ", Amount=" + amount + ", Packaging=" + packaging + "]";
    }
}
