abstract class FoodOrder {
    protected String orderId;
    protected String customerName;
    protected double amount;

    public FoodOrder(String orderId, String customerName, double amount) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.amount = amount;
    }

    public abstract void processOrder();
    public abstract void calculateBill();

    public void displayOrderInfo() {
        System.out.println("Order ID: " + orderId + ", Customer: " + customerName + ", Amount: " + amount);
    }

    public final void finalMethodExample() {
        System.out.println("This final method cannot be overridden.");
    }
}