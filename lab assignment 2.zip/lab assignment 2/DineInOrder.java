class DineInOrder extends FoodOrder {
    private int tableNumber;

    public DineInOrder(String orderId, String customerName, double amount, int tableNumber) {
        super(orderId, customerName, amount);
        this.tableNumber = tableNumber;
    }

    @Override
    public void processOrder() {
        System.out.println("Processing dine-in order for table " + tableNumber);
    }

    @Override
    public void calculateBill() {
        amount = amount + (amount * 0.1);
    }

    public int getTableNumber() { return tableNumber; }
    public void setTableNumber(int tableNumber) { this.tableNumber = tableNumber; }

    @Override
    public String toString() {
        return "DineInOrder [ID=" + orderId + ", Customer=" + customerName + ", Amount=" + amount + ", Table=" + tableNumber + "]";
    }
}