public class Main {
    public static void main(String[] args) {

        FoodOrder o1 = new DineInOrder("D101", "Ali", 2000, 5);
        FoodOrder o2 = new TakeAwayOrder("T202", "Sara", 1500, true);
        FoodOrder o3 = new DeliveryOrder("L303", "Ahmed", 3000, "Model Town, Lahore");


        FoodOrder[] orders = {o1, o2, o3};


        System.out.println("=== Before Modification ===");
        for (FoodOrder order : orders) {
            System.out.println(order);
            order.displayOrderInfo();
            order.processOrder();
            order.calculateBill();
        }


        for (FoodOrder order : orders) {
            if (order instanceof DineInOrder) {
                ((DineInOrder) order).setTableNumber(10);
            }
        }


        for (FoodOrder order : orders) {
            if (order instanceof TakeAwayOrder && ((TakeAwayOrder) order).amount > 1600) {
                System.out.println("TakeAwayOrder exceeds 1600, applying discount...");
                order.amount = order.amount * 0.9;
            }
        }


        System.out.println("\n=== After Modification ===");
        for (FoodOrder order : orders) {
            System.out.println(order);
        }


        if (o1 instanceof DineInOrder) {
            DineInOrder dine = (DineInOrder) o1;
            System.out.println("Downcasted Table Number: " + dine.getTableNumber());
        }




