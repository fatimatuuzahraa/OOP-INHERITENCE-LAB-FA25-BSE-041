class Polygon extends Shape {
    private int numberOfSides;
    private double lengthOfSide;

    public Polygon(String color, double borderThickness, int numberOfSides, double lengthOfSide) {
        super(color, borderThickness);
        this.numberOfSides = numberOfSides;
        this.lengthOfSide = lengthOfSide;
    }

    public int getNumberOfSides() {
        return numberOfSides;
    }

    public void setNumberOfSides(int numberOfSides) {
        this.numberOfSides = numberOfSides;
    }

    public double getLengthOfSide() {
        return lengthOfSide;
    }

    public void setLengthOfSide(double lengthOfSide) {
        this.lengthOfSide = lengthOfSide;
    }

    public void computePerimeter() {
        double perimeter = numberOfSides * lengthOfSide;
        System.out.println("Polygon Perimeter: " + perimeter);
    }

    @Override
    public void draw() {
        System.out.println("Drawing a polygon with " + numberOfSides + " sides...");
    }
}