class Rectangle extends Shape {
    private double rectLength;
    private double rectWidth;

    public Rectangle(String color, double borderThickness, double rectLength, double rectWidth) {
        super(color, borderThickness);
        this.rectLength = rectLength;
        this.rectWidth = rectWidth;
    }

    public double getRectLength() {
        return rectLength;
    }

    public void setRectLength(double rectLength) {
        this.rectLength = rectLength;
    }

    public double getRectWidth() {
        return rectWidth;
    }

    public void setRectWidth(double rectWidth) {
        this.rectWidth = rectWidth;
    }

    public void computeArea() {
        double area = rectLength * rectWidth;
        System.out.println("Rectangle Area: " + area);
    }

    public void computePerimeter() {
        double perimeter = 2 * (rectLength + rectWidth);
        System.out.println("Rectangle Perimeter: " + perimeter);
    }

    @Override
    public void draw() {
        System.out.println("Drawing a rectangle shape...");
    }
}