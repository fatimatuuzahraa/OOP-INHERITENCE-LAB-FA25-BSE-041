public class Test {
    public static void main(String[] args) {

        Shape s = new Shape("Red", 1.5);
        Polygon p = new Polygon("Blue", 2.0, 5, 4.0);
        Rectangle r = new Rectangle("Green", 1.2, 10.0, 5.0);

        System.out.println("----- Shape -----");
        s.displayInfo();
        s.draw();
        System.out.println();

        System.out.println("----- Polygon -----");
        p.displayInfo();
        p.draw();
        p.computePerimeter();
        System.out.println();

        System.out.println("----- Rectangle -----");
        r.displayInfo();
        r.draw();
        r.computeArea();
        r.computePerimeter();
    }
}