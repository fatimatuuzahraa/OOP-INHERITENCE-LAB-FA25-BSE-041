
class Shape {
    private String color;
    private double borderThickness;

  
    public Shape(String color, double borderThickness) {
        this.color = color;
        this.borderThickness = borderThickness;
    }

   
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getBorderThickness() {
        return borderThickness;
    }

    public void setBorderThickness(double borderThickness) {
        this.borderThickness = borderThickness;
    }

    public void displayInfo() {
        System.out.println("Color: " + getColor());
        System.out.println("Border Thickness: " + getBorderThickness());
    }

    public void draw() {
        System.out.println("Drawing a shape");
    }
}
